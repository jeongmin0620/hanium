$(function() {
  $(document).ready(function() {
    $('#select').DataTable();
  });
});